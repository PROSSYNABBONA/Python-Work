#lists,tuples,dictionaries,sets
# the datatype
w=40
print(type(w))
z="Hello"
print(type(z))
x=2.1
print(type(x))
y=0.55
print(type(y))
